# Cetak Nota Bluetooth

Proyek Android Kotlin sederhana untuk menyusun nota penjualan dan mengirimkannya ke printer thermal Bluetooth klasik.

## Cara membuka
1. Ekstrak ZIP.
2. Android Studio > Open > pilih folder `CetakNotaBluetooth`.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).

## Cara memakai
1. Nyalakan printer.
2. Di Pengaturan Android > Bluetooth, cari dan Pair/Padankan printer.
3. Buka aplikasi dan izinkan akses perangkat Bluetooth.
4. Tekan Muat ulang printer berpasangan.
5. Pilih printer, tekan Hubungkan printer.
6. Isi data perusahaan dan toko, tambahkan barang, lalu Cetak Nota.

## Kompatibilitas
Aplikasi memakai Bluetooth Classic RFCOMM SPP dan perintah ESC/POS. Printer harus mendukung mode tersebut. Printer BLE-only atau protokol khusus pabrik mungkin memerlukan kode berbeda. Format awal sekitar 32 kolom (umumnya kertas 58 mm). UTF-8 dan pemotong kertas bergantung pada dukungan firmware printer.

Ini merupakan versi dasar: belum menyimpan riwayat permanen, diskon/PPN, QR code, logo, maupun format rinci persis seperti contoh nota.
