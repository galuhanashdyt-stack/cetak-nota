package com.salespenjualan.cetaknota

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import java.io.OutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

data class ReceiptItem(val name: String, val qty: Int, val price: Int) {
    val total: Int get() = qty * price
}

class MainActivity : Activity() {
    private val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val bt: BluetoothAdapter? get() = BluetoothAdapter.getDefaultAdapter()
    private var socket: BluetoothSocket? = null
    private var output: OutputStream? = null
    private lateinit var status: TextView
    private lateinit var printerSpinner: Spinner
    private lateinit var company: EditText
    private lateinit var companyAddress: EditText
    private lateinit var shop: EditText
    private lateinit var shopAddress: EditText
    private lateinit var shopCode: EditText
    private lateinit var salesman: EditText
    private lateinit var itemName: EditText
    private lateinit var itemQty: EditText
    private lateinit var itemPrice: EditText
    private lateinit var itemList: TextView
    private val devices = mutableListOf<BluetoothDevice>()
    private val items = mutableListOf<ReceiptItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createUi()
        askPermission()
        refreshPrinters()
    }

    private fun createUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 28)
            setBackgroundColor(0xFFF4F3FA.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)
        root.addView(text("CETAK NOTA BLUETOOTH", 23f, true))
        root.addView(text("Nota penjualan tunai • Printer thermal ESC/POS", 14f))
        status = text("Status: belum terhubung", 14f, true)
        root.addView(status)
        printerSpinner = Spinner(this)
        root.addView(printerSpinner)
        root.addView(btn("Muat ulang printer berpasangan") { refreshPrinters() })
        root.addView(btn("Hubungkan printer") { connectPrinter() })
        root.addView(btn("Putuskan koneksi") { disconnectPrinter() })

        root.addView(text("INFORMASI PERUSAHAAN", 18f, true))
        company = edit("Nama perusahaan", "PT. NAMA PERUSAHAAN")
        companyAddress = edit("Alamat perusahaan", "Alamat perusahaan")
        root.addView(company); root.addView(companyAddress)

        root.addView(text("INFORMASI TOKO", 18f, true))
        shop = edit("Nama toko / pelanggan", "")
        shopAddress = edit("Alamat toko", "")
        shopCode = edit("Kode toko", "")
        salesman = edit("Nama salesman", "")
        root.addView(shop); root.addView(shopAddress); root.addView(shopCode); root.addView(salesman)

        root.addView(text("TAMBAH BARANG", 18f, true))
        itemName = edit("Nama barang", "")
        itemQty = edit("Jumlah", "1")
        itemPrice = edit("Harga satuan (angka)", "0")
        root.addView(itemName); root.addView(itemQty); root.addView(itemPrice)
        root.addView(btn("Tambah barang ke nota") { addItem() })
        itemList = text("Belum ada barang", 14f)
        root.addView(itemList)
        root.addView(btn("Hapus semua barang") { items.clear(); refreshItems() })
        root.addView(text("CETAK NOTA", 18f, true))
        root.addView(btn("CETAK NOTA SEKARANG") { printReceipt() })
        root.addView(text("Pasangkan printer terlebih dahulu dari Pengaturan Bluetooth Android. Aplikasi ini mendukung printer Bluetooth Classic SPP yang menerima ESC/POS; printer BLE-only mungkin tidak kompatibel.", 12f))
    }

    private fun text(value: String, size: Float = 16f, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(0xFF202040.toInt())
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        setPadding(0, 9, 0, 9)
    }
    private fun edit(hintText: String, value: String) = EditText(this).apply {
        hint = hintText; setText(value); textSize = 15f; singleLine = true
        setPadding(14, 6, 14, 6)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 }
    }
    private fun btn(value: String, action: () -> Unit) = Button(this).apply {
        text = value; isAllCaps = false; setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 5 }
    }
    private fun askPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 10)
        }
    }
    private fun permitted() = Build.VERSION.SDK_INT < 31 ||
        ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun refreshPrinters() {
        if (bt == null) { status.text = "Bluetooth tidak tersedia"; return }
        if (!permitted()) { askPermission(); return }
        try {
            if (bt?.isEnabled != true) { status.text = "Aktifkan Bluetooth HP dahulu"; return }
            devices.clear()
            devices.addAll(bt!!.bondedDevices.sortedBy { it.name ?: it.address })
            val names = devices.map { "${it.name ?: "Printer"} (${it.address})" }
            printerSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
                names.ifEmpty { listOf("Belum ada perangkat berpasangan") })
            status.text = if (devices.isEmpty()) "Pair printer dari Pengaturan Bluetooth dahulu" else "Ditemukan ${devices.size} perangkat"
        } catch (_: SecurityException) { status.text = "Izin Bluetooth belum diberikan" }
    }
    private fun connectPrinter() {
        if (!permitted()) { askPermission(); return }
        val device = devices.getOrNull(printerSpinner.selectedItemPosition)
        if (device == null) { toast("Pair printer melalui Pengaturan Bluetooth dahulu"); return }
        status.text = "Menghubungkan..."
        thread {
            try {
                socket?.close()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                bt?.cancelDiscovery()
                s.connect()
                socket = s; output = s.outputStream
                runOnUiThread { status.text = "Terhubung: ${device.name}"; toast("Printer terhubung") }
            } catch (e: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                socket = null; output = null
                runOnUiThread { status.text = "Gagal terhubung: ${e.message}" }
            }
        }
    }
    private fun disconnectPrinter() {
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        output = null; socket = null
        if (::status.isInitialized) status.text = "Status: belum terhubung"
    }
    private fun addItem() {
        val n = itemName.text.toString().trim()
        val q = itemQty.text.toString().toIntOrNull()
        val p = itemPrice.text.toString().toIntOrNull()
        if (n.isBlank() || q == null || q < 1 || p == null || p < 0) {
            toast("Periksa nama barang, jumlah, dan harga"); return
        }
        items.add(ReceiptItem(n, q, p)); itemName.text.clear(); refreshItems()
    }
    private fun idr(n: Int) = NumberFormat.getNumberInstance(Locale("id", "ID")).format(n)
    private fun refreshItems() {
        itemList.text = if (items.isEmpty()) "Belum ada barang" else
            items.mapIndexed { i, v -> "${i + 1}. ${v.name} | ${v.qty} x ${idr(v.price)} = ${idr(v.total)}" }
                .joinToString("\n") + "\nTOTAL: Rp ${idr(items.sumOf { it.total })}"
    }
    private fun printReceipt() {
        if (socket?.isConnected != true || output == null) { toast("Hubungkan printer dahulu"); return }
        if (items.isEmpty()) { toast("Tambahkan barang dahulu"); return }
        val bytes = receiptText().toByteArray(Charsets.UTF_8)
        thread {
            try {
                val stream = output ?: error("Printer terputus")
                stream.write(byteArrayOf(0x1B, 0x40))
                stream.write(bytes)
                stream.write(byteArrayOf(10, 10, 10))
                stream.write(byteArrayOf(0x1D, 0x56, 0x00))
                stream.flush()
                runOnUiThread { toast("Nota berhasil dikirim ke printer") }
            } catch (e: Exception) { runOnUiThread { toast("Cetak gagal: ${e.message}") } }
        }
    }
    private fun receiptText(): String {
        val total = items.sumOf { it.total }
        val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("id", "ID")).format(Date())
        return buildString {
            append(company.text).append('\n')
            append(companyAddress.text).append('\n')
            append("--------------------------------\n")
            append("       ** NOTA PENJUALAN **\n")
            append("No.       : ${System.currentTimeMillis().toString().takeLast(8)}\n")
            append("Tanggal   : $date\n")
            append("Nama      : ${shop.text}\n")
            append("Alamat    : ${shopAddress.text}\n")
            append("Kode Toko : ${shopCode.text}\n")
            append("--------------------------------\n")
            append("ITEM BARANG\n")
            items.forEach {
                append(it.name).append('\n')
                append("${it.qty} x Rp ${idr(it.price)} = Rp ${idr(it.total)}\n")
            }
            append("--------------------------------\n")
            append("TOTAL PEMBAYARAN: Rp ${idr(total)}\n\n")
            append("Barang telah diterima\n\n")
            append("Ttd Toko:             Salesman:\n")
            append("(${shop.text})       (${salesman.text})\n\n")
            append("          Terima kasih\n")
        }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { disconnectPrinter(); super.onDestroy() }
}
